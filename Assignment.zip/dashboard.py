import numpy as np
import matplotlib.pyplot as plt
 
# creating the dataset
data = {'Jan':55, 'Feb':70, 'Mar':40,
        'April':55,'May':60, 'June':40, 'July':50,
        'Aug':70, 'Sep':55, 'Oct':75, 'Nov':45,
        'Dec':75}
courses = list(data.keys())
values = list(data.values())
  
fig = plt.figure(figsize = (40, 20))
 
# creating the bar plot
plt.bar(courses, values, color ='blue',
        width = 0.3)
 
plt.ylabel("GNPA Trend")
plt.title("Credit Analytics Dashboard")
plt.show()
